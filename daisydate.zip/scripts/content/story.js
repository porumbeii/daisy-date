class Story {
    constructor(file) {
        Content.Story = this;
        fetch(file)
            .then(response => response.text())
            .then(data => {
                this.Data = data;
                Content.StoryIsLoaded = true;
            });
    }
}