class Vector {
    constructor(x, y) {
        this.X = x;
        this.Y = y;
    }
}